function displayContactInfo() {
    var auntContactInfo = ["Paula", "Smith", "1234 Main Street", "St. Louis", "MO", 12345];
    console.log(auntContactInfo);
}

//This will print the information in the string variable auntContactInfo:"Paula", "Smith", "1234 Main Street", "St. Louis", "MO", 12345

function displayGrocerylist() {
    var produce = ["apples", "oranges"];
    var frozen = ["broccoli", "ice cream"];
    frozen.push("hashbrowns");
    console.log(frozen);
}

//This will print the information in the string variable frozen: "broccoli", "ice cream", "hashbrowns"

var movieLibrary = ["Bambi", "E.T.", "Toy Story"];
movieLibrary.push("Zoro");
movieLibrary[1] = "Beetlejuice";
console.log(movieLibrary);

//This will print the information in the string variable movieLibrary: "Bambi", "Beetlejuice", "Toy Story", "Zoro" 

